Herding Cats SDL2 Multi-Window Application 
================================================ 
 
Version: 1.0.0 
Platform: Windows 10/11 x64 
Architecture: x86_64 
 
Hardware Acceleration: ENABLED 
Multi-Window Support: External Floating Windows 
Performance: 60 FPS with VSync 
 
QUICK START: 
1. Run herding-cats-rust.exe 
2. Press Ctrl+1-6 to create tool windows 
3. Press ESC to exit 
 
SYSTEM REQUIREMENTS: 
- Windows 10 or Windows 11 
- 64-bit processor 
- Graphics card with OpenGL/DirectX support 
- DirectX 11 or later for optimal performance 
 
TROUBLESHOOTING: 
- Ensure all DLL files are in the same directory as the executable 
- Run as Administrator if you encounter permission issues 
- Check that your graphics drivers are up to date 
 
Build Date: Wed 11/05/25 10:59:11.09 
SDL2 Version: 0.38.0 
